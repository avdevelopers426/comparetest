var shouldstart =false;
const currentUrl = window.location.href;
const urlObject = new URL(currentUrl);
const params = new URLSearchParams(urlObject.search);
const pagescrap = params.get('pagescrap');
const gde_redirect = params.get('redirect');
const openpoup = params.get('openpoup');
window.onload = function() {

      console.log("Docaaument is !"+currentUrl);
     
      setInterval(function(){ 
        console.log(document.querySelectorAll('.results_listing_container > div').length);
        if(document.querySelectorAll('.results_listing_container > div').length){
          const hasQueryString = currentUrl.includes('?');
          let start_string_url = '';
          if(hasQueryString){
            start_string_url = currentUrl+'&pagescrap=yes&openpoup=yes';
          }else{
            start_string_url = currentUrl+'?pagescrap=yes&openpoup=yes';
          }

          const customHtml = `
            <style>
            
            .jde_content_start{
              position: fixed;
              top: 20px;
              right: 20px;
              left: auto;
              z-index: 9999999;
              background-color: #fe610c;
              padding: 20px;
              animation: glowing 1500ms infinite;
                  border-radius: 7px;
            }
            .jde_content_message_start a{
              font-size:20px;
              color:#fff;
              font-weight:bold;
            }
            @keyframes glowing {
              0% { background-color: #0076d7; box-shadow: 0 0 3px #fe610c; }
              50% { background-color: #0076d7; box-shadow: 0 0 40px #fe610c; }
              100% { background-color: #0076d7; box-shadow: 0 0 3px #fe610c; }
            }
            </style>
            <div class="jde_content_start"><div class="jde_content_message_start"><a href="${start_string_url}">Start Scraping</a></div></div>
            <div class="jde_overly_start"></div>
          `;
          console.log("pagescrap");
          console.log(pagescrap);
          if(pagescrap==null) {
            
            if(document.querySelectorAll('.jde_content_start').length==0){
              document.body.insertAdjacentHTML('beforeend', customHtml);
            }
          }

        }
      }, 2000);
      
};

console.log("hhhhhff"+currentUrl);
x=0;



console.log(params);
console.log(params.get('pagescrap'));

//const gde_action = params.get('gde_action');
//alert(gde_action);
console.log("sdfasdfafaa");
if(openpoup) {
  chrome.storage.local.set({ jd_data: [] }, function() {
    console.log("clean chrome.storage.session");
  });
}
if(pagescrap) {

  gde_showloader();
  shouldstart =true;
  jde_processItems();

}
if(gde_redirect) {
  gde_showloader('Scrapping Completed');
}

async function jde_processItems() {
  var nextdata_element = document.querySelector('#__NEXT_DATA__');
  if (nextdata_element) {
    var nextdata = JSON.parse(nextdata_element.textContent);
    if (nextdata.props.pageProps.listData.results.data) {
      const columns = nextdata.props.pageProps.listData.results.columns;
      const includeIndicesAndValues = columns.map(key => ({ key, index: columns.indexOf(key) }));
       var currentx=0;

       for (const item of nextdata.props.pageProps.listData.results.data) {
        const includedData = {};
        /*console.log("item");
        console.log(item);*/
        includeIndicesAndValues.forEach(data => {
          // Check if the key exists in the current item
          if (item[data.index]) {
            includedData[data.key] = item[data.index];
          }
        });
        var phoneget = await gofromscraping(includedData['docid']);
        includedData['phone'] = phoneget;
        //console.log(includedData);
        if(document.querySelectorAll('#jde_content_badget_main').length!=0){
          currentx = currentx +1;
          const customHtml = `
            <div class="jde_content_badget">
              <div class="jde_content_badget_head">Scrapping Record Out ${currentx}  of ${nextdata.props.pageProps.listData.results.data.length}</div>
              <div class="jde_content_badget_title">${includedData['name']}</div>
            </div>
            
          `;
          document.getElementById('jde_content_badget_main').innerHTML = customHtml;
        }
        await JdupdateData(includedData);

        await jde_sleep(2000);
      }
    }
    var linkElement = document.querySelector('link[rel="next"]');
    if (linkElement) {
      chrome.storage.local.get({ purchase_date: '',product_key: '',expire_date: '' }, function(data) {
          console.log(data);
        if(data.expire_date!=''){
            const givenDate = new Date(data.expire_date);
            const currentDate = new Date();
            if (givenDate < currentDate) {
                chrome.runtime.sendMessage({ 
                  action: "open_popup",
                  msg:"Key Expire"
                });
                document.getElementById("jde_content_message").innerHTML = "Scrapping Completed For More Record Buy Product Key";
            }else{
                console.log("redirectopen_popup");
                var nexturl = linkElement.getAttribute('href');
                window.location.href = nexturl+'?pagescrap=yes';
            }
        }else{
            chrome.runtime.sendMessage({ 
                  action: "open_popup",
                  msg:"Buy Product Key For More Record"
            });
        }
      });
    }else{
      gde_showloader('Scrapping Completed');
      chrome.runtime.sendMessage({ 
                    action: "open_popup",
                    msg:"SuccessFully Done"
              });
    }
  }
}
function gde_showloader(message='Wait Till Scrapping , Don;t Close Tab') {
  const loaderDiv = document.querySelector('.jde_content');
  if (loaderDiv) {
    loaderDiv.querySelector('.jde_content_message').textContent = message;
  } else {
    const customHtml = `
      <style>
      .jde_overly{
        background-color: #000;
        position: fixed;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        z-index: 99;
        opacity: 0.5;
      }
      .jde_content{
        position: fixed;
        top: 20px;
        right: auto;
        left: 20px;
        z-index: 9999999;
        background-color: #0076d7;
        padding: 20px;
      }
      .jde_content_message{
        font-size:30px;
        color:#fff;
        font-weight:bold;
      }
      .jde_content_badget{
        position: fixed;
        top: auto;
        right: auto;
        left: 20px;
        bottom:20px;
        z-index: 9999999;
        background-color: #fe610c;
        padding: 15px;
        color: #fff;
        font-size:18px;
      }
      .jde_content_badget .jde_content_badget_head{
        font-weight:bold;
      }

      </style>
      <div class="jde_content"><div class="jde_content_message" id="jde_content_message">`+message+`</div></div>
      <div class="jde_overly"></div>
      <div id="jde_content_badget_main"></div>
      
    `;
    document.body.insertAdjacentHTML('beforeend', customHtml);
  }
}
   
function jde_isElementVisibleByClass(className) {
  const element = document.querySelector('.' + className);
  if (element) {
    const computedStyle = getComputedStyle(element);
    return computedStyle.display !== 'none' && computedStyle.visibility !== 'hidden';
  }
  return false;
}

function jde_sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForElement(selector, timeout = 3000) {
  const start = Date.now();

  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    if (el) {
      return el;
    }
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

  return null;
}


async function gofromscraping(x){
  //console.log(x);
  if (jde_isElementVisibleByClass('jd_modal_close')) {
     document.querySelector('.jd_modal_close').click();
  }
  pickclass = '[id="'+x+'"]';
  console.log(pickclass);
  phonumber = document.querySelector(pickclass+' .callcontent').textContent;
    if(phonumber=='Show Number'){
       //console.log("Show Number1");
       document.querySelector(pickclass+' .button_flare').click();
     
        //console.log("Show Number2");
        await waitForElement(pickclass+' .whitecall_icon');
        //console.log("Show Number3");
        phonumber = document.querySelector(pickclass+' .callcontent').textContent.trim();
        if(phonumber=='Show Number'){
          //console.log("Show Number4");
          await waitForElement(pickclass+'+.jd_contact_info_pop li:nth-child(1)');
          //console.log("Show Number5");
          //console.log(document.querySelector(pickclass+'+.jd_contact_info_pop li:nth-child(1)'));
          const contactInfoElement = document.querySelectorAll(pickclass + '+.jd_contact_info_pop li');
         
          if (contactInfoElement) {
            const phonumberarry = Array.from(contactInfoElement).map(element => element.textContent.trim());
            phonumber=phonumberarry.join(', ');
            //console.log("phonumber");
            //console.log(contactInfoElement);
            //console.log(phonumber);
          }else{
            //console.log('Contact info element not found');
          }
          //await jde_sleep(200000);
        }
        if(document.querySelector(pickclass+'+.jd_contact_info_pop .jd_modal_close')){
          document.querySelector(pickclass+'+.jd_contact_info_pop .jd_modal_close').click();
        }
        //console.log('phonumberphonumber');
        //console.log(phonumber);
          
       
    }else{
       //console.log('phonumberphonumberphonumberphonumber');
       //console.log(phonumber);
     }
     return phonumber;
}

function JdgetCurrentTime() {
  // Create a new Date object
  const currentDate = new Date();

  // Get the current time components
  const hours = currentDate.getHours();
  const minutes = currentDate.getMinutes();
  const seconds = currentDate.getSeconds();

  // Format the time as a string
  const currentTime = `${JdformatTimeComponent(hours)}:${JdformatTimeComponent(minutes)}:${JdformatTimeComponent(seconds)}`;

  return currentTime;
}

// Helper function to format time components (add leading zero if needed)
function JdformatTimeComponent(component) {
  return component < 10 ? "0" + component : component;
}

async function JdupdateData(dataarr) {
  //console.log(typeof dataarr);
  // Retrieve existing data from chrome.storage.local
  chrome.storage.local.get({ jd_data:[] }, function (data) {
   console.log(dataarr);
    console.log(data.jd_data);
    // Extract the existing object from the retrieved data
    var existingarr = data.jd_data || [];
    //existingarr.push(dataarr);
    existingarr = existingarr.concat(dataarr);
    //console.log(existingarr);
    // Save the modified object back to chrome.storage.local
    chrome.storage.local.set({ jd_data: existingarr }, function () {
      console.log("Element added to the object in chrome.storage.local");
    });
  });
 
}