const clear_data = document.getElementById('clear_data');
const export_data = document.getElementById('export_data');
const start_url_api = document.getElementById('start_url_api');
const start_url_table = document.getElementById('start_url_table');

const purchase_key = document.getElementById('purchase_key');

const errorAlert = document.getElementById('errorAlert');
const errorText = document.getElementById('errorText');
const closeErrorAlert = document.getElementById('closeErrorAlert');


var itemsFormatted = [];
document.addEventListener('DOMContentLoaded', function () {

    chrome.storage.local.get({ purchase_date: '',product_key: '',expire_date: '' }, function(data) {
        console.log(data);
       if(data.expire_date!=''){
            const givenDate = new Date(data.expire_date);
            const currentDate = new Date();
            if (givenDate < currentDate) {
                start_url_api.style.display = 'block';
                start_url_table.style.display = 'none';
            }else{
                start_url_api.style.display = 'none';
                start_url_table.style.display = 'block';
            }
        }else{
            start_url_api.style.display = 'block';
            start_url_table.style.display = 'none';
        }
        
        
    });

    start_url_api.addEventListener('submit', function (event) {
        event.preventDefault();
        const urla = "https://www.codesmade.com/api/jd/api.php?product_key="+purchase_key.value;
        const headers = {
            'Content-Type': 'application/json',
        };


        fetch(urla, {
            method: 'GET',
            headers: headers,
        })
            .then(response => response.json())
            .then(responseData => {
                // Process the responseData here
                console.log(responseData);
                if(responseData['status'] == 'yes'){
                    chrome.storage.local.set({ 
                        "purchase_date": responseData['purchase_date'],
                        "product_key": responseData['product_key'],
                        "expire_date": responseData['expire_date'], 
                    }).then(() => {
                      console.log("Value is set");
                      location.reload();
                    });
                }else{
                    showError("Enter Valid Key");
                }
            })
            .catch(error => {
                // Handle errors here
                console.error('Error:', error);
            });

    });

   clear_data.addEventListener('click', function() {
      event.preventDefault();
      document.getElementById('currentProcessedCount').innerHTML=0;
      document.getElementById('tbl_items_list').innerHTML='';
  });
  export_data.addEventListener('click', function() {
      event.preventDefault();
      if (itemsFormatted.length === 0) {
        //showError("No Records Exists");
      }else{
        exportCSVFile();
      }
      
  });
  closeErrorAlert.addEventListener('click', function() {
    hideError();
  });
});
indexshow = 0;
let tableBody = document.querySelector('#tbl_items_list');
let thead_tr = document.querySelector('#thead_tr');
let headersInitialized = false;
let includeKeys = ["docid","name", "totalReviews", "city","area","NewAddressln","opennow","phone", "thumbnail", "lat", "lon", "weburl", "pincode", "verified"];
chrome.storage.local.get({ jd_data: [] }, function(data) {
    var existingArray = data.jd_data || [];
    console.log("Session data loaded successfully");
    console.log(existingArray);
    var htmlcreat = '';
    for (const item of existingArray) {
        // Add the item to the HTML table
        indexshow = indexshow + 1;
       
        if (!headersInitialized && typeof item === 'object' && item !== null) {
            // Initialize table headers based on object keys
            Object.values(includeKeys).forEach(key => {
                const th = document.createElement('th');
                th.textContent = key;
                th.classList.add('text-gray-700'); 
                th.classList.add('dark:text-gray-400'); 
                th.classList.add('px-4'); 
                th.classList.add('py-2'); 
                thead_tr.appendChild(th);
            });
            headersInitialized = true;
        }
        
        htmlcreat += '<tr class="text-gray-700 dark:text-gray-400">';
          // Check if item is an object
            if (typeof item === 'object' && item !== null) {
                // Iterate over object properties
                var rowData = {}; 
                Object.values(includeKeys).forEach(key => {
                    
                    htmlcreat += '<td class="px-4 py-2">';
                    //console.log(key);
                    if(key=='weburl'){
                        htmlcreat += 'https://www.justdial.com/'+item[key];
                    }else{
                        htmlcreat += item[key];
                    }
                    
                    htmlcreat += '</td>';
                    rowData[key] = item[key];
                });
                itemsFormatted.push(rowData);
            } else {
                console.error('Item is not an object:', item);
                // Handle the case where item is not an object
            }
        htmlcreat += '</tr>';

        
        

       
    }

    tableBody.innerHTML = htmlcreat;
    document.getElementById('currentProcessedCount').innerHTML = tableBody.childElementCount;

  
});

//generate function 
function showError(message) {
  errorText.innerText = message;
  errorAlert.classList.remove('hidden');
}

// Function to hide the error alert
function hideError() {
  errorAlert.classList.add('hidden');
}


function exportCSVFile() {
    items = itemsFormatted;
     
    fileTitle = "data"
    

    // Convert Object to JSON
    var jsonObject = JSON.stringify(items);

    var csv = this.convertToCSV(jsonObject);

    var exportedFilenmae = fileTitle + '.csv' || 'export.csv';

    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, exportedFilenmae);
    } else {
        var link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            var url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", exportedFilenmae);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
}
function convertToCSV(objArray) {
    var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    var str = '';

    // Handle headers
    var keys = Object.keys(array[0]);
    str += keys.join(',') + '\n';

    // Handle values
    for (var i = 0; i < array.length; i++) {
        var line = '';
        for (var index in array[i]) {
            if (line != '') line += ',';

            var value = array[i][index];
            if (typeof value === 'string') {
                value = value.replace(/"/g, '""'); // escape double quotes
                if (value.indexOf(',') !== -1) {
                    value = '"' + value + '"'; // wrap in double quotes if it contains commas
                }
            }
            line += value;
        }
        str += line + '\r\n';
    }

    return str;
}

chrome.runtime.onMessage.addListener(function (message) {
  console.log(message);
  if (message.action === "alert_popup") {
    showError(message.msg)
  }
});