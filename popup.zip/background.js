/*let popupWindow = null;*/

// Listen for the browser action click event

chrome.action.onClicked.addListener(tab => { 
    chrome.tabs.create({url: 'popup.html'}) 

    
});

/*chrome.windows.onRemoved.addListener(function(windowId) {
    console.log("gggggdd");
    console.log(popupWindow);
    console.log(windowId);
    if (popupWindow && popupWindow.id === windowId) {
        popupWindow = null; // Set the popupWindow variable to null
    }
});*/
// Listen for messages from the popup
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === "open_popup") {
        chrome.tabs.create({ url: 'popup.html' }, function (tab) {
            console.log("tabIdopen_popup");
            setTimeout(function(){ 
                console.log("tabIdopen_popupsetTimeout");
                chrome.runtime.sendMessage({ 
                    action: "alert_popup",
                    msg:message.msg
                });
             }, 2000);
            
        });
    }
    chrome.storage.local.get(["key"]).then((result) => {
        console.log("Value currently is " + result.key);
      });
    
    chrome.storage.local.get({ jd_data: [] }, function(data) {
        var existingArray = data.jd_data || [];
        console.log("session");
        console.log(existingArray);
    });
    console.log("message");
    console.log(message);
    /*popupWindow.id*/

    
});

